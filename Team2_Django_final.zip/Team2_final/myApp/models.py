from unicodedata import name
from django.db import models

# Create your models here.
# ORM 방식으로 테이블 생성
# 학생 테이블


class B_elder_TA(models.Model):
    location = models.CharField(max_length=100)   # 지점명
    occr = models.IntegerField(default=0)  # 발생건수
    death = models.IntegerField(default=0)  # 사망자수
    lo = models.IntegerField(default=0)  # 경도
    la = models.IntegerField(default=0)  # 위도

    def __str__(self):
        return self.name


class B_kin_TA(models.Model):
    location = models.CharField(max_length=100)  # 지점명
    occr = models.IntegerField(default=0)  # 발생건수
    death = models.IntegerField(default=0)  # 사망자수
    lo = models.IntegerField(default=0)  # 경도
    la = models.IntegerField(default=0)  # 위도

    def __str__(self):
        return self.name
