# myApp/urls.py

from django.urls import path
from . import views

urlpatterns = [

    # 시작페이지 주소와 뷰함수 연결
    path('', views.index),

    # city 테이블 모델의 전체 목록 표시 주소
    # /myApp/city/
    path('list1/', views.list1),

    # city 테이블 모델의 전체 목록 표시 주소
    # /myApp/city/
    path('list2/', views.list2),


    path('search/', views.search),

    path('searchCon/', views.searchCon),

    path('base_map/', views.base_map),

    path('elder_map/', views.elder_map),

    path('kin_map/', views.kin_map),

]
