from django.contrib import admin

# Register your models here.

# 모델파일 임포트
# Student, City 테이블
from .models import B_elder_TA, B_kin_TA

admin.site.register(B_elder_TA)

admin.site.register(B_kin_TA)
