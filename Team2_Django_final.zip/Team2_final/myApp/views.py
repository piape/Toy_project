from pkgutil import get_data
from pyrsistent import b
from .models import B_elder_TA, B_kin_TA
import requests
import json
from django.shortcuts import render
# 추가
import pandas as pd
import numpy as np
from folium import plugins
import folium
import geocoder

# 데이타프레임의 컬럼을 10컬럼까지 모두 표시
pd.set_option('display.max_columns', 10)

# /, /myApp/ 주소와 연결되는 뷰함수


def index(request):
    return render(request, 'myApp/intro.html')


def list1(request):
    # 테이블모델명.objects.all()
    elder_list = B_elder_TA.objects.all()
    # 딕셔너리 구조로 만들어서 html 문서에 전달
    context = {'elder_list': elder_list}
    return render(request, 'myApp/list1.html', context)


def list2(request):
    # 테이블모델명.objects.all()
    kin_list = B_kin_TA.objects.all()
    # 딕셔너리 구조로 만들어서 html 문서에 전달
    context = {'kin_list': kin_list}
    return render(request, 'myApp/list2.html', context)


def search(request):
    return render(request, 'myApp/search.html')


def searchCon(request):
    # 폼에서 GET방식으로 전달받은 데이타를 변수에 저장
    search_word = request.GET['search']

    # 결과리스트명 = 테이블명.objects.filter(필드명__icontains=search_word)
    elder_list = B_elder_TA.objects.filter(location__icontains=search_word)
    print('='*50)
    print(search_word)

    # 딕셔너리 구조로 만들어서 html 문서에 전달
    context = {'elder_list': elder_list}

    return render(request, 'myApp/search_result.html', context)


g = geocoder.ip('me')

# Create your views here.


def base_map(request):
    map = folium.Map(location=[35.175428916312, 129.10782261902],
                     zoom_start=12,
                     width='100%', height='100%',)
    plugins.LocateControl().add_to(map)
    plugins.Geocoder().add_to(map)

    maps = map._repr_html_()

    context = {'map': maps}

    return render(request, 'myApp/base_map.html', context)


def elder_map(request):
    map = folium.Map(location=[35.175428916312, 129.10782261902],
                     zoom_start=12,
                     width='100%', height='100%',)
    plugins.LocateControl().add_to(map)
    plugins.Geocoder().add_to(map)

    maps = map._repr_html_()

    context = {'map': maps}

    return render(request, 'myApp/elder_map.html', context)


def kin_map(request):
    map = folium.Map(location=[35.175428916312, 129.10782261902],
                     zoom_start=12,
                     width='100%', height='100%',)
    plugins.LocateControl().add_to(map)
    plugins.Geocoder().add_to(map)

    maps = map._repr_html_()

    context = {'map': maps}

    return render(request, 'myApp/kin_map.html', context)
